gamemode creative @s
tp @s 6013.5 180 6008.2 0 26
