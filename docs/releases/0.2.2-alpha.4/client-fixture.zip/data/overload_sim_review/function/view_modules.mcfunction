gamemode spectator @s
tp @s 6025.7 180.6 6010.8 0 65
