gamemode creative @s
tp @s 5997 184 6006 -45 25
