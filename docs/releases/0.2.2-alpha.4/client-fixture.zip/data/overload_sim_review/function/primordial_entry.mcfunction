execute as @a at @s run function overload_sim_review:primordial_setup
