gamemode creative @s
tp @s 6025.5 180 6008.2 0 26
